package com.fauxcode.riyazz;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;



public class Page_1 extends android.support.v4.app.Fragment implements SeekBar.OnSeekBarChangeListener {
LinearLayout l1;
Context context;
    private  Button playMusic;
    private MediaPlayer mediaPlayer;
    int flag=0;
    private SeekBar seekBar1;
    ListView list;
    ListView list1;
    String m="Teental";
    TextView tv,tv1;
    MyListAdapter adapter;
 Handler handler;
 Runnable runnable;
 AudioManager am;
    float speed=0.5f;
    String[] maintitle={
            "SELECT FIRST STRING"
    };

    String[] subtitle ={
            " "
    };


    private void updatePosition() {


    }


    public Page_1(){
    };

    @Nullable

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View Page_one=inflater.inflate(R.layout.page1, container, false);

        seekBar1 =(SeekBar)Page_one.findViewById(R.id.sliderr);



        am=(AudioManager)getActivity().getSystemService(Context.AUDIO_SERVICE);
        seekBar1.setMax((int) 6.0f);
        seekBar1.setProgress((int) 15.5f);
        seekBar1.setOnSeekBarChangeListener(Page_1.this);


        return Page_one;

    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        MyListAdapter adapter = new MyListAdapter(getActivity(), maintitle, subtitle);

        tv = (TextView) getActivity().findViewById(R.id.textView);


        list = (ListView) view.findViewById(R.id.list11);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                registerForContextMenu(list);
                getActivity().openContextMenu(list);
            }
        });

        mediaPlayer=new MediaPlayer();

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {

            }
        });
        playMusic = (Button) getActivity().findViewById(R.id.playButton1);
        playMusic.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {


                //stop and give option to start again
                mediaPlayer.pause();
                //playMusic.setText("Pause");
                Toast.makeText(getActivity(),"pause mp 1",Toast.LENGTH_SHORT).show();
                playMusic.setBackgroundColor(R.color.colorAccent);

            }
        });


    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        seContentView(R.layout.activity_main);

/*
*/

    }



    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

            menu.setHeaderTitle("SELECT FIRST STRING");
            menu.add(0, v.getId(), 0, "SA");
            menu.add(0, v.getId(), 0, "RE KOMAL");
            menu.add(0, v.getId(), 0, "RE");
        menu.add(0, v.getId(), 0, "GA KOMAL");
        menu.add(0, v.getId(), 0, "GA");
        menu.add(0, v.getId(), 0, "MA");
        menu.add(0, v.getId(), 0, "MA TIVRA");
        menu.add(0, v.getId(), 0, "PA");
        menu.add(0, v.getId(), 0, "DHA KOMAL");

        menu.add(0, v.getId(), 0, "DHA");
        menu.add(0, v.getId(), 0, "NI KOMAL");
        menu.add(0, v.getId(), 0, "NI");
    }



    @SuppressLint("ResourceAsColor")
    @Override
    public boolean onContextItemSelected(MenuItem item) {


    m = item.getTitle().toString();
    if (m == "SA") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.sa);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);

    } else if (m == "RE KOMAL") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.rekomal);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);

    } else if (m == "RE") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.re);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);

    } else if (m == "GA KOMAL") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.gakomal);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "GA") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.ga);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "MA") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.ma);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "MA TIVRA") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.mativra);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "PA") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.pa);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "DHA KOMAL") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.dhakomal);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "DHA") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.dha);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "NI KOMAL") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.nikomal);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    } else if (m == "NI") {
        playMusic.setBackgroundColor(R.color.colorPrimaryDark);
        mediaPlayer = MediaPlayer.create(getActivity(), R.raw.ni);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);
    }


        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

       // Toast.makeText(getActivity(),item.getTitle(),Toast.LENGTH_SHORT).show();
       // m=item.getTitle().toString();
        return super.onOptionsItemSelected(item);

    }


    private void seContentView(int activity_main) {


    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
        float speed=(float)progress;
        mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
