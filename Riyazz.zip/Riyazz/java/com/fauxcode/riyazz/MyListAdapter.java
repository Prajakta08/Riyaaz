package com.fauxcode.riyazz;

import android.app.Activity;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.fauxcode.riyazz.R;

import java.util.List;

public class MyListAdapter extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] Maintitle;
    private final String[] Subtitle;


    public MyListAdapter(Activity context, String[] maintitle, String[] subtitle) {
        super(context, R.layout.mylist, maintitle);

        this.context = context;
        this.Maintitle = maintitle;
        this.Subtitle = subtitle;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();
        View rowview = inflater.inflate(R.layout.mylist, null, true);

        TextView maintitle = (TextView) rowview.findViewById(R.id.textView);
        TextView subtitle = (TextView) rowview.findViewById(R.id.textview2_1);

        maintitle.setText(Maintitle[position]);
        subtitle.setText(Subtitle[position]);



        return rowview;
    }




}
