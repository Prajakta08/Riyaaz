package com.fauxcode.riyazz;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaController;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;



public class Page_3 extends android.support.v4.app.Fragment implements SeekBar.OnSeekBarChangeListener {
private  int tt;
    private Button playMusic;
    private MediaPlayer mediaPlayer;
    TextView tv;
    ListView list;
    String m="Dha";
    MyListAdapter3 adapter;
    private SeekBar seekbar;
    AudioManager am;
   float speed=0.75f;
Context context;
    int flag=0;

    String[] maintitle ={
            "SHRUTI"

    };

    String[] subtitle ={
            " "
    };
    public Page_3(){};
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View Page_three=inflater.inflate(R.layout.page3, container, false);
        seekbar =(SeekBar)Page_three.findViewById(R.id.slider3);



        am=(AudioManager)getActivity().getSystemService(Context.AUDIO_SERVICE);
        seekbar.setMax((int) 6.0f);
        seekbar.setProgress((int) 15.5f);
        seekbar.setOnSeekBarChangeListener(Page_3.this);


        return Page_three;

    }





    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MyListAdapter3 adapter = new MyListAdapter3(getActivity(), maintitle, subtitle);

        tv = (TextView) view.findViewById(R.id.textView2__3);

        list = (ListView) view.findViewById(R.id.list33);
        list.setAdapter(adapter);





        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    registerForContextMenu(list);
                    getActivity().openContextMenu(list);


            }
        });
        mediaPlayer = new MediaPlayer();

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {

            }
        });

        playMusic = (Button) getActivity().findViewById(R.id.playButton3);
        playMusic.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {

                if(mediaPlayer.isPlaying()) {

                    mediaPlayer.pause();
                    Toast.makeText(getActivity(),"pause mp 3",Toast.LENGTH_SHORT).show();
                    playMusic.setBackgroundColor(R.color.colorAccent);

                }
            }

        });


    }



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        // menu.clear();

            menu.setHeaderTitle("Select raag");
            menu.add(0, v.getId(), 0, "Sarang");
            menu.add(0, v.getId(), 0, "Bhairav");
            menu.add(0, v.getId(), 0, "Kafi");
            menu.add(0, v.getId(), 0, "Bhimpalasi");
            menu.add(0, v.getId(), 0, "Durga");
            menu.add(0, v.getId(), 0, "Kamod");
            menu.add(0, v.getId(), 0, "Todi");
            menu.add(0, v.getId(), 0, "Pahadi");
            menu.add(0, v.getId(), 0, "Des");


        }
    @SuppressLint("ResourceAsColor")
    @Override
    public boolean onContextItemSelected(MenuItem item) {

        m = item.getTitle().toString();
            if (m == "Des") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.de);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Kafi") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.dee);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Bhimpalasi") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.deee);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Pahadi") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.tr);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Sarang") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.trw);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Todi") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.x);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Durga") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.xz);

                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Kamod") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.xzz);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Bhairav") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.xz);

                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            } else if (m == "Bhimpalasi") {
                playMusic.setBackgroundColor(R.color.colorPrimaryDark);
                mediaPlayer = MediaPlayer.create(getActivity(), R.raw.deee);
                mediaPlayer.start();
                mediaPlayer.setLooping(true);
            }


            return super.onContextItemSelected(item);


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {



        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
        float speed=(float)progress;

        mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
