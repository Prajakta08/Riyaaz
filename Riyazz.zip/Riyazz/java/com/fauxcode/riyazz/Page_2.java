package com.fauxcode.riyazz;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**

 */

public class Page_2 extends android.support.v4.app.Fragment implements SeekBar.OnSeekBarChangeListener {

    private Button playMusic;
    private MediaPlayer mediaPlayer;
    TextView tv;
    ListView list;
   private SeekBar seekbar;
AudioManager am;
    String m;
    MyListAdapter2 adapter;

    int flag=0;

    String[] maintitle ={
            "SELECT TABLA"

    };

    String[] subtitle ={
            " "
    };
    public Page_2(){};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View Page_two=inflater.inflate(R.layout.page2, container, false);
        seekbar =(SeekBar)Page_two.findViewById(R.id.slider2);

        am=(AudioManager)getActivity().getSystemService(Context.AUDIO_SERVICE);
        seekbar.setMax((int) 6.0f);
        seekbar.setProgress((int) 15.5f);
        seekbar.setOnSeekBarChangeListener(Page_2.this);

        return Page_two;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MyListAdapter2 adapter = new MyListAdapter2(getActivity(), maintitle, subtitle);

       tv=(TextView)getActivity().findViewById(R.id.textView_2);

        list = (ListView) view.findViewById(R.id.list22);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                registerForContextMenu(list);
                getActivity().openContextMenu(list);
            }
        });

        mediaPlayer = new MediaPlayer();


         mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
             @Override
             public void onCompletion(MediaPlayer mp) {

             }
         });

        playMusic = (Button) getActivity().findViewById(R.id.playButton2);
        playMusic.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {

                if(mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    //playMusic.setText("Pause");
                    Toast.makeText(getActivity(),"pause mp 2",Toast.LENGTH_SHORT).show();


                    playMusic.setBackgroundColor(R.color.colorAccent);
                }
                }

        });

            }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        // menu.clear();
        menu.setHeaderTitle("SELECT TAAL");
        menu.add(0, v.getId(), 0, "ADA CHAUTAAL");
        menu.add(0, v.getId(), 0, "DEEPCHANDI");
        menu.add(0, v.getId(), 0, "DHAMAR");
        menu.add(0, v.getId(), 0, "JHOOMRA");
        menu.add(0, v.getId(), 0, "EKTAAL");
        menu.add(0, v.getId(), 0, "CHAUTAAL");
        menu.add(0, v.getId(), 0, "ZAPTAAL");
    }


    @SuppressLint("ResourceAsColor")
    @Override
    public boolean onContextItemSelected(MenuItem item) {


        m=item.getTitle().toString();
        if(m=="ADA CHAUTAAL")
        {
            playMusic.setBackgroundColor(R.color.colorPrimaryDark);
            mediaPlayer = MediaPlayer.create(getActivity(),R.raw.adachautaal);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }
        else if(m=="CHAUTAAL")
        {
            playMusic.setBackgroundColor(R.color.colorPrimaryDark);
            mediaPlayer = MediaPlayer.create(getActivity(),R.raw.chautaal);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }
        else if(m=="DEEPCHANDI")
        {
            playMusic.setBackgroundColor(R.color.colorPrimaryDark);
            mediaPlayer = MediaPlayer.create(getActivity(),R.raw.deepchandi);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }
        else if(m=="DHAMAR")
        {
            playMusic.setBackgroundColor(R.color.colorPrimaryDark);
            mediaPlayer = MediaPlayer.create(getActivity(),R.raw.dhamar);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }
        else if(m=="JHOOMRA")
        {
            playMusic.setBackgroundColor(R.color.colorPrimaryDark);
            mediaPlayer = MediaPlayer.create(getActivity(),R.raw.jhoomra);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }else if(m=="EKTAAL")
        {
            playMusic.setBackgroundColor(R.color.colorPrimaryDark);
            mediaPlayer = MediaPlayer.create(getActivity(),R.raw.ektaal);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }else if(m=="ZAPTAAL")
        {
            playMusic.setBackgroundColor(R.color.colorPrimaryDark);
            mediaPlayer = MediaPlayer.create(getActivity(),R.raw.zaptaal);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Toast.makeText(getActivity(),item.getTitle(),Toast.LENGTH_SHORT).show();
        // m=item.getTitle().toString();
        return super.onOptionsItemSelected(item);

    }


    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
        float speed=(float)progress;

        mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
