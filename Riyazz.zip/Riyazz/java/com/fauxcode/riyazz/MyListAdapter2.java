package com.fauxcode.riyazz;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class MyListAdapter2 extends ArrayAdapter<String>{

    private final Activity context;
    private final String[] maintitle;
    private final String[] Subtitle;


    public MyListAdapter2(Activity context, String[] maintitle, String[] subtitle) {
        super(context, R.layout.mylist2, maintitle);

        this.context = context;
        this.maintitle = maintitle;
        this.Subtitle = subtitle;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();
        View rowview = inflater.inflate(R.layout.mylist2, null, true);

        TextView titleText = (TextView) rowview.findViewById(R.id.textView_2);
        TextView subtitle = (TextView) rowview.findViewById(R.id.textView2_2);

        titleText.setText(maintitle[position]);
        subtitle.setText(Subtitle[position]);


        return rowview;
    }

}
